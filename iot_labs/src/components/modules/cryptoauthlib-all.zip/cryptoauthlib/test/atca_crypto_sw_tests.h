/**
 * \file
 * \brief Unity tests for the CryptoAuthLib software crypto API.
 *
 * \copyright (c) 2015-2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL
 * LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED
 * THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR
 * THIS SOFTWARE.
 */

#ifndef ATCA_CRYPTO_TESTS_H_
#define ATCA_CRYPTO_TESTS_H_

#include "third_party/unity/unity.h"

int atca_crypto_sw_tests(int argc, char* argv[]);

void test_atcac_sw_sha1_nist1(void);
void test_atcac_sw_sha1_nist2(void);
void test_atcac_sw_sha1_nist3(void);
void test_atcac_sw_sha1_nist_short(void);
void test_atcac_sw_sha1_nist_long(void);
void test_atcac_sw_sha1_nist_monte(void);
void test_atcac_sw_sha2_256_nist1(void);
void test_atcac_sw_sha2_256_nist2(void);
void test_atcac_sw_sha2_256_nist3(void);
void test_atcac_sw_sha2_256_nist_short(void);
void test_atcac_sw_sha2_256_nist_long(void);
void test_atcac_sw_sha2_256_nist_monte(void);

void test_atcac_aes128_gcm(void);
void test_atcac_aes128_cmac(void);
void test_atcac_sha256_hmac(void);
void test_atcac_sha256_hmac_nist(void);

#endif